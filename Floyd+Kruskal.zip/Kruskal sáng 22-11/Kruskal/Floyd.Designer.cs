﻿namespace Kruskal
{
    partial class Floyd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Chaybtn = new System.Windows.Forms.Button();
            this.Huybtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Chon1cbx = new System.Windows.Forms.ComboBox();
            this.Chon2cbx = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Chaybtn
            // 
            this.Chaybtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chaybtn.Location = new System.Drawing.Point(422, 96);
            this.Chaybtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Chaybtn.Name = "Chaybtn";
            this.Chaybtn.Size = new System.Drawing.Size(142, 50);
            this.Chaybtn.TabIndex = 0;
            this.Chaybtn.Text = "Chạy";
            this.Chaybtn.UseVisualStyleBackColor = true;
            this.Chaybtn.Click += new System.EventHandler(this.Chaybtn_Click);
            // 
            // Huybtn
            // 
            this.Huybtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huybtn.Location = new System.Drawing.Point(422, 240);
            this.Huybtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Huybtn.Name = "Huybtn";
            this.Huybtn.Size = new System.Drawing.Size(142, 50);
            this.Huybtn.TabIndex = 0;
            this.Huybtn.Text = "Huỷ";
            this.Huybtn.UseVisualStyleBackColor = true;
            this.Huybtn.Click += new System.EventHandler(this.Huybtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(158, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Chạy thuật toán Floyd";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 96);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Từ đỉnh:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 256);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Đến:";
            // 
            // Chon1cbx
            // 
            this.Chon1cbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Chon1cbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chon1cbx.FormattingEnabled = true;
            this.Chon1cbx.Location = new System.Drawing.Point(127, 93);
            this.Chon1cbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Chon1cbx.Name = "Chon1cbx";
            this.Chon1cbx.Size = new System.Drawing.Size(64, 33);
            this.Chon1cbx.TabIndex = 2;
            this.Chon1cbx.SelectedIndexChanged += new System.EventHandler(this.Chon1cbx_SelectedIndexChanged);
            // 
            // Chon2cbx
            // 
            this.Chon2cbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Chon2cbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chon2cbx.FormattingEnabled = true;
            this.Chon2cbx.Location = new System.Drawing.Point(127, 253);
            this.Chon2cbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Chon2cbx.Name = "Chon2cbx";
            this.Chon2cbx.Size = new System.Drawing.Size(64, 33);
            this.Chon2cbx.TabIndex = 2;
            // 
            // Floyd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(656, 378);
            this.Controls.Add(this.Chon2cbx);
            this.Controls.Add(this.Chon1cbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Huybtn);
            this.Controls.Add(this.Chaybtn);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Floyd";
            this.Text = "Floyd";
            this.Load += new System.EventHandler(this.Floyd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Chaybtn;
        private System.Windows.Forms.Button Huybtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Chon1cbx;
        private System.Windows.Forms.ComboBox Chon2cbx;
    }
}