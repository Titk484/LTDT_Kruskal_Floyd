﻿namespace Kruskal
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnDocDoThi = new System.Windows.Forms.Button();
            this.btnTimCayKhungFloyd = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnTaoDoThi = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblTrangThai = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnTimCayKhungKruskal = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDocDoThi
            // 
            this.btnDocDoThi.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnDocDoThi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocDoThi.Location = new System.Drawing.Point(68, 165);
            this.btnDocDoThi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDocDoThi.Name = "btnDocDoThi";
            this.btnDocDoThi.Size = new System.Drawing.Size(191, 70);
            this.btnDocDoThi.TabIndex = 0;
            this.btnDocDoThi.Text = "Đọc đồ thị";
            this.btnDocDoThi.UseVisualStyleBackColor = false;
            this.btnDocDoThi.Click += new System.EventHandler(this.btnDocDoThi_Click);
            // 
            // btnTimCayKhungFloyd
            // 
            this.btnTimCayKhungFloyd.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnTimCayKhungFloyd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimCayKhungFloyd.Location = new System.Drawing.Point(68, 253);
            this.btnTimCayKhungFloyd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTimCayKhungFloyd.Name = "btnTimCayKhungFloyd";
            this.btnTimCayKhungFloyd.Size = new System.Drawing.Size(191, 70);
            this.btnTimCayKhungFloyd.TabIndex = 1;
            this.btnTimCayKhungFloyd.Text = "Floyd";
            this.btnTimCayKhungFloyd.UseVisualStyleBackColor = false;
            this.btnTimCayKhungFloyd.Click += new System.EventHandler(this.btnTimCayKhungFloyd_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.Location = new System.Drawing.Point(68, 439);
            this.btnLuu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(191, 70);
            this.btnLuu.TabIndex = 2;
            this.btnLuu.Text = "Lưu đồ thị và cây";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnTaoDoThi
            // 
            this.btnTaoDoThi.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnTaoDoThi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaoDoThi.Location = new System.Drawing.Point(68, 78);
            this.btnTaoDoThi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTaoDoThi.Name = "btnTaoDoThi";
            this.btnTaoDoThi.Size = new System.Drawing.Size(191, 70);
            this.btnTaoDoThi.TabIndex = 3;
            this.btnTaoDoThi.Text = "Tạo đồ thị";
            this.btnTaoDoThi.UseVisualStyleBackColor = false;
            this.btnTaoDoThi.Click += new System.EventHandler(this.btnTaoDoThi_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(291, 78);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(705, 431);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.White;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblTrangThai});
            this.statusStrip1.Location = new System.Drawing.Point(0, 528);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1100, 26);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblTrangThai
            // 
            this.lblTrangThai.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Size = new System.Drawing.Size(75, 20);
            this.lblTrangThai.Text = "Trạng thái";
            // 
            // btnTimCayKhungKruskal
            // 
            this.btnTimCayKhungKruskal.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnTimCayKhungKruskal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimCayKhungKruskal.Location = new System.Drawing.Point(68, 343);
            this.btnTimCayKhungKruskal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnTimCayKhungKruskal.Name = "btnTimCayKhungKruskal";
            this.btnTimCayKhungKruskal.Size = new System.Drawing.Size(191, 70);
            this.btnTimCayKhungKruskal.TabIndex = 8;
            this.btnTimCayKhungKruskal.Text = "Kruskal";
            this.btnTimCayKhungKruskal.UseVisualStyleBackColor = false;
            this.btnTimCayKhungKruskal.Click += new System.EventHandler(this.btnTimCayKhungKruskal_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.SteelBlue;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(0, -98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1067, 172);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SteelBlue;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.label2.Location = new System.Drawing.Point(53, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(970, 36);
            this.label2.TabIndex = 11;
            this.label2.Text = "THUẬT TOÁN TÌM CÂY KHUNG NHỎ NHẤT KRUSKAL VÀ FLOYD";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1100, 554);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnTimCayKhungKruskal);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btnTaoDoThi);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnTimCayKhungFloyd);
            this.Controls.Add(this.btnDocDoThi);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnDocDoThi;
		private System.Windows.Forms.Button btnTimCayKhungFloyd;
		private System.Windows.Forms.Button btnLuu;
		private System.Windows.Forms.Button btnTaoDoThi;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel lblTrangThai;
		private System.Windows.Forms.Button btnTimCayKhungKruskal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

